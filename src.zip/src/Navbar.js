export default function Navbar() {
    return <nav className="nav">
        <a href="/" className="site-title">Sam23</a>
        <ul>
            <li className="active">
                <a href="/home">Home</a>
            </li>
            <li>
                <a href="/cars">Cars</a>
            </li>
            <li>
                <a href="/contact">Contact Us</a>
            </li>
        </ul>
    </nav>
}