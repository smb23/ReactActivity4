import Navbar from "./Navbar";
import Home from "./pages/Home";
import Cars from "./pages/Cars";
import Contact from "./pages/Contact";
import Footer from './components/Footer';

function App() {
  let component
  
  // eslint-disable-next-line default-case
  switch (window.location.pathname) {
    case "/home":
      component = <Home />
      
      break
  
    case "/cars":
      component = <Cars /> 

      break

    case "/contact":
      component = <Contact />

      break
  }


  return (
  <>
    <Navbar />
    {component}
    <Footer />
  </>
  )
}


export default App;
