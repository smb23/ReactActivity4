export default function Home (){
    return <h2>"Princess just wants a new car.
    I have told her that hers will go far.
    'Oh, it's really not cool
    driving this crap to school.'
    'Do I need that emotional scar? '
    
    'The kids will all laugh at the rust.
    When we race, I'll be left in the dust! 
    I will save up some cash
    then we'll make a mad dash
    to the car dealer surely you trust'.
    
    'He will make us a wonderful deal
    and I'm sure you will know how I feel.
    I will love you so much, 
    My siblings... I won't touch.
    Just get me behind a new wheel'! 
    
    Now she'll be cruisin in style.
    She'll be happy for only awhile.
    There will always be better
    and we'll try hard to get her
    a car that will make princess smile."</h2>
}