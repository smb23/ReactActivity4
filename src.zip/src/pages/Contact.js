export default function Contact (){
    return <table>
        <div>
             Email: <textarea></textarea>                                     
        </div><span></span><br />
        <div>
             Full Name: <textarea></textarea>  
        </div><span></span><br />
        <div>
             Inquiry: <textarea></textarea>
        </div><span></span><br />
        <div>
             <button>Submit</button>
        </div>
         </table>
  

    
}